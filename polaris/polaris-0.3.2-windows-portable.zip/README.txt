RavLight Polaris — preview build (Windows)
==========================================

A fleet manager for RavLight devices. It runs on a PC and you use it from a
browser, on that machine or from a phone on the same network. It finds devices,
shows what each one is patched as, plans addresses across a rig, and updates
firmware. It does not send DMX — a console keeps that job.

Start here:    https://ravlight.com/docs/polaris.html   (the full guide)
What changed:  CHANGELOG.md
Licence:       LICENSE.txt  —  free to use, including commercially;
                               please don't redistribute it


Two ways to run it
------------------

INSTALLED — run polaris-setup-<version>.exe

  Registers Polaris as a Windows service, adds the firewall rules it needs, and
  puts three things in the Start menu: Open RavLight Polaris, the tray icon and
  the uninstaller. The desktop shortcut starts everything at once — the tray, the
  service if it is not running, and the page once it answers.

  It runs at boot from then on. To stop it, or to stop it doing that, use the
  tray icon: Stop service, or clear "Start at boot", which leaves it installed
  and startable when you want it. "Stop Polaris and close" stops the service and
  closes the icon; there is deliberately no way to dismiss the icon and leave the
  service running.

PORTABLE — double-click polaris.exe

  No installation and no administrator rights. Everything it stores lives in a
  "data" folder beside the binary; delete that folder and it is as if it never
  ran. The console window it opens is the program, so closing it stops it.

Either way the interface is at  http://localhost:8420

Windows will ask whether to allow it through the firewall (the installer adds
the rules itself). It needs that to find devices: discovery is UDP, and a device
replies to a fixed port rather than to the port the probe came from — so without
an inbound rule for udp/4211 every scan comes back empty and looks like a
network fault.

This build is unsigned, so SmartScreen will warn about an unknown publisher.


What the files are
------------------

  polaris-setup-<version>.exe   the installer
  polaris.exe                   Polaris itself, and its command line
  polaris-tray.exe              starts the tray without a console window
  fakedevice.exe                a device simulator, for trying it without a rig
  LICENSE.txt                   the licence you are using it under
  THIRD-PARTY-NOTICES.txt       the open-source components it is built from

polaris-tray.exe does nothing but run polaris.exe with no window attached. It is
a separate file because a console program brings its console along when started
from a shortcut, and linking Polaris itself as a windowless program would break
its command line.


Trying it without hardware
--------------------------

    fakedevice.exe -mix veyron=6,orion=6,elyon=4 -base 20

The simulated fixtures live on loopback addresses (127.0.0.x), so they never
appear on your network. Nothing real lives there either, which is why Polaris
has to be told to look:

    polaris.exe serve -data .\data -loopback

Sixteen simulated fixtures then appear alongside any real ones; both are found
the same way and both can be patched. Add

    -dead RVV06,RVE04 -dead-after 150s

to have two of them stop answering after two and a half minutes, which is how
the offline handling is meant to be tried.


Before pointing it at a real rig
--------------------------------

  - It writes device configuration when you tell it to. Addresses apply live;
    ids and IP addresses reboot the device.
  - There is no authentication anywhere — not in Polaris, not on the devices.
    The security model is the network: a lighting VLAN, not a login.
  - Firmware updates take a fixture dark for the whole flash, so Polaris does a
    couple at a time and sends the first on its own.
  - It has been exercised on a bench, against a lot of simulated devices, and on
    real hardware by a second user. It has not been through a show.

Feedback on any of that is the point of this build:  dav_rav@hotmail.it
