# Changelog

What changed, in the words somebody using it would use. Version numbers are
preview numbers, and the builds are not code-signed, so Windows will warn
about an unknown publisher.

## 0.3.3 — 2 September 2026

- **Devices running firmware older than 2.23.0 can be updated again.** They answered
  *upload rejected: 500 Internal Server Error* and there was no way past it. The endpoint
  Polaris posts to arrived with the OTA handler that replaced ElegantOTA in 2.23.0, so on
  anything older it simply is not there — and firmware before 2.24.0 answers a route it
  does not have with 500 rather than 404, which makes a device that is working perfectly
  look broken. Polaris now speaks the older two-step flow when the version it discovered
  calls for it, sending the image MD5 up front so the device verifies what it received.
- **An image too big for an old device is refused before anything is written.** Firmware
  from before 2.23.3 has smaller application slots, so an image that fits every current
  board can still not fit there. Finding that out halfway through the write means
  recovering the device over USB, so the size is checked first and the answer says so.

## 0.3.2 — 2 September 2026

The release that can actually be handed to somebody.

- **Fixed: an update could have installed an image that does not boot.** Polaris
  downloaded whatever file the release feed named and sent it to the device, and
  the device picks which partition to write from the filename alone. A wrong
  entry in one small JSON file on the website was therefore enough to push a
  merged full-flash image, or another board's firmware, to a whole fleet — and a
  device that takes one of those does not come back over the network. The feed is
  now checked before anything is downloaded: the image has to be the app-only
  build, for this board, and it has to fit in an application slot. Manual imports
  were always checked; this path never was.
- **A licence and third-party notices.** Polaris is free to use, including
  commercially, and not to be redistributed — point people at ravlight.com so
  everybody gets the current build. The open-source components it is built from
  are listed with their licences in full.
- Both are installed beside the binary and shown by the installer.

## 0.3.1 — 2 September 2026

Local control, after installing it made it hard to switch off.

- **A tray icon** — the one place that can stop Polaris without locking you out
  of it. Whether it is running, open it, start or stop the service, and whether
  Windows starts it at boot. The only way out of the menu stops the service as
  well: an icon you can dismiss while the service keeps running is the state
  nobody can reason about.
- The tray opens no console window. It is started by a second, tiny GUI binary
  that runs polaris.exe with no window attached, because linking Polaris itself
  as a GUI application would have fixed the window and broken the command line —
  a shell does not wait for a GUI process, so `polaris devices` would return
  before it had printed.
- The desktop shortcut starts the whole thing: the tray, the service if it is not
  running, and the page once it answers.
- **Fixed: double-clicking the installed binary died** with *mkdir
  C:\Program Files\RavLight\Polaris\data: access denied*. It looks for a
  Polaris that is already answering first — after an install one always is — and
  opens that. Where nothing is running and the folder beside the binary cannot be
  written to, it uses the user's own application data.
- **Fixed: `polaris status` needed administrator rights** for a question whose
  answer is public. It and the start type are read with query rights now, which
  is also how the tray polls them without a prompt every three seconds.
- The RavLight mark is the icon everywhere: the binary, the installer, the
  shortcuts and the tray.

## 0.3.0 — 2 September 2026

The release where a group became a list of fixtures rather than a list of blocks,
and where what Polaris holds for a production became a file you can carry.

### Projects

- **A project is everything Polaris holds for a production** — the fleet and the
  patch — and it saves to a file and opens from one. Prepared at the workshop,
  opened in the venue.
- A fixture in the file that this machine has never met is recorded as *expected*,
  with the configuration the file remembers, so the patch reads correctly before
  anything answers. Discovery decides the rest. One that was a placeholder stays a
  placeholder.
- **New project** starts from nothing. Groups and placeholders always go; the
  inventory is a separate question, because a rig that lives in a building keeps
  its fixtures and a hire stock going to another venue does not.
- What never travels: telemetry, the event log, the firmware cache and this
  machine's settings. They are facts about a PC on a LAN, not about a production.

### Groups

- **One row per fixture**, showing what it is actually set to: personality, start
  address, footprint, the universes it occupies, the address it answers on and
  whether that address is held by DHCP. All on one line.
- **Block addresses are fields you type in.** Setting the first one lays the rest
  out from it, each by its own size — a Veyron's from the personality's section
  table, an Elyon output's from its pixel count and grouping.
- **Plan asks first**: how DMX reaches the group, where the addresses start, what
  happens at the end of a universe. Then it fills the blocks in blue with what it
  proposes, and **Send it** writes them after showing every change by fixture.
- **Where a fixture takes DMX from** can be set at last — Art-Net, sACN, or the
  five-pin line. Nothing here could write it before, so every rig Polaris has
  touched was on whatever the firmware defaulted to.
- **An Orion is two fixtures in one box**: a winch addressed from the device
  universe and LED outputs carrying their own. They get a row each, joined or
  split as you prefer, and each is reached its own way. Its outputs used to be
  missing from the patch entirely.
- Fixtures move between groups in one action, and the group **saves itself** —
  Send it is the only button on that page that writes to a rig.
- A fixture that is switched off no longer stops a group from being applied. Its
  addresses are kept in Polaris and go to the hardware when there is some.

### Devices

- Edit a fixture on its own — personality, universe, start channel, DMX input,
  and its address — from the row or from its panel. Written to it if it answers,
  kept here if it does not.
- **Download configuration** and **Upload configuration**, under the names the
  fixture's own page uses. A file for the wrong fixture type is refused.
- Add to a group, replace a dead fixture with a spare, and place offline
  devices with a full configuration so that binding one to real hardware sends
  the right settings rather than somebody else's.
- Removing a device now tells every open browser, instead of leaving a ghost row
  until a reload.

### Network

- Every address this machine holds, grouped by adapter — a card holding a
  lighting VLAN and the office network is two segments, and Polaris probes both.
- **Which interfaces to probe** and **which extra subnets to sweep** are settable
  here rather than by editing a file, and a subnet can be swept once, now.
- A warning listing fixtures on segments this machine has no address on, saying
  which of them are reachable by routing and which are not reachable at all.
- The Art-Net and sACN listener can be turned off, so a console or a media server
  on the same machine can have udp/6454.

### Firmware

- **Fixed: an update could report success and flash nothing.** The upload was
  sent without a Content-Length, which the device's web server silently ignores —
  it replied 200 and rebooted onto the old image.
- Selecting a device narrows the image list to that fixture's build, and a device
  that does not report which build it takes can be named explicitly, with the
  warning that a wrong binary does not come back over the network.
- Two upload buttons that did nothing now upload.

### Elsewhere

- The header and tabs stay put while a long list scrolls, and the search bar
  sticks under them.
- One typeface throughout, the same one the fixtures' own pages use, with tabular
  figures so a column of addresses still lines up.
- The Scan button shows how long since the fleet last answered.
- The device simulator can make fixtures go quiet on cue, which is how the
  offline paths above were tested.

## 0.2.1 — 31 August 2026

Preview build: discovery, the device list, groups with an allocator, firmware
updates, the Art-Net listener.
